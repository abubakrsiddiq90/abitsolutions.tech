using System.ComponentModel;

namespace AB_ERP_POS2.Models
{
    public class MenuItem : INotifyPropertyChanged
    {
        private int _stock;

        public int ItemId { get; set; }
        public int CategoryId { get; set; }
        public string ItemCode { get; set; } = string.Empty;
        public string ItemName { get; set; } = string.Empty;
        public string ShortName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Barcode { get; set; } = string.Empty;
        public decimal CostPrice { get; set; }
        public decimal BasePrice { get; set; }
        public int TaxId { get; set; }
        public int PreparationTime { get; set; }
        public bool IsFood { get; set; }
        public bool IsBeverage { get; set; }
        public bool IsAlcoholic { get; set; }
        public bool IsCombo { get; set; }
        public bool HasRecipe { get; set; }
        public bool IsActive { get; set; } = true;

        // UI properties
        public string Name => ItemName;
        public decimal Price => BasePrice;
        public string Category { get; set; } = string.Empty;
        public string ImagePath { get; set; } = string.Empty;

        public int Stock
        {
            get => _stock;
            set
            {
                _stock = value;
                OnPropertyChanged(nameof(Stock));
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
