using System.ComponentModel;

namespace AB_ERP_POS2.Models
{
    public enum TableStatus
    {
        Available,
        Occupied,
        Unpaid,
        Reserved
    }

    public class Table : INotifyPropertyChanged
    {
        private TableStatus _status;
        private decimal _currentTotal;
        private string _currentOrderNumber = string.Empty;

        public int TableId { get; set; }
        public int OutletId { get; set; }
        public string TableNumber { get; set; } = string.Empty;
        public string TableName { get; set; } = string.Empty;
        public int Capacity { get; set; } = 4;
        public string Section { get; set; } = string.Empty;

        public TableStatus Status
        {
            get => _status;
            set
            {
                _status = value;
                OnPropertyChanged(nameof(Status));
                OnPropertyChanged(nameof(StatusColor));
                OnPropertyChanged(nameof(StatusText));
            }
        }

        public decimal CurrentTotal
        {
            get => _currentTotal;
            set
            {
                _currentTotal = value;
                OnPropertyChanged(nameof(CurrentTotal));
                OnPropertyChanged(nameof(DisplayTotal));
            }
        }

        public string CurrentOrderNumber
        {
            get => _currentOrderNumber;
            set
            {
                _currentOrderNumber = value;
                OnPropertyChanged(nameof(CurrentOrderNumber));
            }
        }

        public string DisplayTotal => CurrentTotal > 0 ? $"₦{CurrentTotal:N0}" : "";
        public string StatusText => Status.ToString();

        public string StatusColor
        {
            get
            {
                return Status switch
                {
                    TableStatus.Available => "#90EE90",
                    TableStatus.Occupied => "#87CEEB",
                    TableStatus.Unpaid => "#FFE4B5",
                    TableStatus.Reserved => "#FFB6C1",
                    _ => "#90EE90"
                };
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
