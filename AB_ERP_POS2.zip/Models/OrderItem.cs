using System.ComponentModel;

namespace AB_ERP_POS2.Models
{
    public class OrderItem : INotifyPropertyChanged
    {
        private decimal _quantity;
        private decimal _discountAmount;
        private decimal _taxAmount;

        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public int ItemId { get; set; }

        public decimal Quantity
        {
            get => _quantity;
            set
            {
                _quantity = value;
                OnPropertyChanged(nameof(Quantity));
                OnPropertyChanged(nameof(TotalAmount));
                OnPropertyChanged(nameof(DisplayTotal));
            }
        }

        public decimal UnitPrice { get; set; }

        public decimal DiscountAmount
        {
            get => _discountAmount;
            set
            {
                _discountAmount = value;
                OnPropertyChanged(nameof(DiscountAmount));
                OnPropertyChanged(nameof(TotalAmount));
                OnPropertyChanged(nameof(DisplayTotal));
            }
        }

        public decimal TaxAmount
        {
            get => _taxAmount;
            set
            {
                _taxAmount = value;
                OnPropertyChanged(nameof(TaxAmount));
            }
        }

        public decimal TotalAmount => (UnitPrice * Quantity) - DiscountAmount + TaxAmount;
        public string Notes { get; set; } = string.Empty;

        // UI properties
        public MenuItem? MenuItem { get; set; }
        public int ItemNumber { get; set; }
        public string DisplayName => MenuItem?.ItemName ?? "Unknown";
        public string DisplayPrice => $"₦{UnitPrice:N0}";
        public string DisplayTotal => $"₦{TotalAmount:N0}";

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
