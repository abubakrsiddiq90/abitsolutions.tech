using System;
using System.ComponentModel;

namespace AB_ERP_POS2.Models
{
    public enum BillStatus
    {
        Open,
        Printed,
        Paid,
        Partial,
        Cancelled,
        Refunded
    }

    public class Bill : INotifyPropertyChanged
    {
        public int BillId { get; set; }
        public string BillNo { get; set; } = string.Empty;
        public int OrderId { get; set; }
        public int BranchId { get; set; }
        public int OutletId { get; set; }
        public int? TableId { get; set; }
        public string TableNumber { get; set; } = string.Empty;
        public int? CustomerId { get; set; }
        public int? CashierId { get; set; }
        public string BillType { get; set; } = "standard";
        public decimal Subtotal { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal ServiceCharge { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal Rounding { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal BalanceDue { get; set; }
        public decimal TipAmount { get; set; }
        public BillStatus BillStatus { get; set; } = BillStatus.Open;
        public int PrintCount { get; set; }
        public DateTime BillDate { get; set; }
        public TimeSpan BillTime { get; set; }
        public DateTime? SettledAt { get; set; }
        public string Notes { get; set; } = string.Empty;
        public bool IsCleared { get; set; }
        public DateTime CreatedAt { get; set; }

        public string DisplayStatus => BillStatus.ToString();
        public string DisplayTotal => $"₦{TotalAmount:N2}";
        public string DisplayDate => BillDate.ToString("dd/MM/yyyy");

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
