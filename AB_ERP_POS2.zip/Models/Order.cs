using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace AB_ERP_POS2.Models
{
    public enum OrderStatus
    {
        Pending,
        Confirmed,
        Preparing,
        Ready,
        Served,
        Completed,
        Cancelled
    }

    public class Order : INotifyPropertyChanged
    {
        private decimal _discountAmount;
        private OrderStatus _status;
        private decimal _serviceCharge;

        public int OrderId { get; set; }
        public string OrderNumber { get; set; } = string.Empty;
        public int BranchId { get; set; }
        public int OutletId { get; set; }
        public int? TableId { get; set; }
        public int? WaiterId { get; set; }
        public int? CustomerId { get; set; }
        public DateTime OrderTime { get; set; } = DateTime.Now;
        public string OrderType { get; set; } = "dine_in";
        public int GuestCount { get; set; } = 1;
        public string SpecialInstructions { get; set; } = string.Empty;
        public string CustomerName { get; set; } = "Walk-in Customer";
        public string CashierName { get; set; } = string.Empty;
        public string TableNumber { get; set; } = string.Empty;

        public OrderStatus Status
        {
            get => _status;
            set
            {
                _status = value;
                OnPropertyChanged(nameof(Status));
                OnPropertyChanged(nameof(StatusString));
            }
        }

        public string StatusString => Status.ToString().ToLower();

        public decimal DiscountAmount
        {
            get => _discountAmount;
            set
            {
                _discountAmount = value;
                OnPropertyChanged(nameof(DiscountAmount));
                OnPropertyChanged(nameof(TaxAmount));
                OnPropertyChanged(nameof(TotalAmount));
                OnPropertyChanged(nameof(DisplaySubtotal));
                OnPropertyChanged(nameof(DisplayDiscount));
                OnPropertyChanged(nameof(DisplayVAT));
                OnPropertyChanged(nameof(DisplayTotal));
            }
        }

        public decimal ServiceCharge
        {
            get => _serviceCharge;
            set
            {
                _serviceCharge = value;
                OnPropertyChanged(nameof(ServiceCharge));
                OnPropertyChanged(nameof(TotalAmount));
                OnPropertyChanged(nameof(DisplayTotal));
            }
        }

        public decimal SubTotal => Items.Sum(i => i.UnitPrice * i.Quantity);
        public decimal TaxAmount => (SubTotal - DiscountAmount) * 0.075m;
        public decimal TotalAmount => (SubTotal - DiscountAmount) + TaxAmount + ServiceCharge;

        public bool IsBillCleared { get; set; }
        public bool HasUnclearedBill { get; set; }
        public DateTime? BillPrintedAt { get; set; }
        public DateTime? DocketPrintedAt { get; set; }

        public ObservableCollection<OrderItem> Items { get; set; } = new ObservableCollection<OrderItem>();

        // Display helpers
        public string DisplaySubtotal => $"₦{SubTotal:N0}";
        public string DisplayDiscount => $"₦{DiscountAmount:N2}";
        public string DisplayVAT => $"₦{TaxAmount:N2}";
        public string DisplayTotal => $"₦{TotalAmount:N2}";
        public int ItemCount => Items.Count;

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void Recalculate()
        {
            OnPropertyChanged(nameof(SubTotal));
            OnPropertyChanged(nameof(TaxAmount));
            OnPropertyChanged(nameof(TotalAmount));
            OnPropertyChanged(nameof(DisplaySubtotal));
            OnPropertyChanged(nameof(DisplayDiscount));
            OnPropertyChanged(nameof(DisplayVAT));
            OnPropertyChanged(nameof(DisplayTotal));
            OnPropertyChanged(nameof(ItemCount));
        }
    }
}
