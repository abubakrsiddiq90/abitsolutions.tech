using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using AB_ERP_POS2.Models;
using AB_ERP_POS2.Services;
using AB_ERP_POS2.Windows;

namespace AB_ERP_POS2.Views
{
    public partial class OrderEntry : Window
    {
        // ─── FIELDS ───────────────────────────────────────────
        private List<MenuItem> _allMenuItems = new();
        private List<MenuItem> _filteredMenuItems = new();
        private List<Table> _tables = new();
        private List<Order> _activeOrders = new();
        private Order _currentOrder = new();
        private Table? _selectedTable;
        private int _currentPage = 1;
        private const int _pageSize = 18;
        private int _totalPages = 1;
        private string _currentCategory = "All Items";
        private readonly DispatcherTimer _clockTimer;
        private readonly int _branchId = 1;
        private readonly int _outletId = 1;
        private readonly int _cashierId = 1;
        private readonly string _cashierName = "Abubakar";

        // ─── CONSTRUCTOR ─────────────────────────────────────
        public OrderEntry()
        {
            InitializeComponent();
            _clockTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _clockTimer.Tick += ClockTimer_Tick;
            _clockTimer.Start();

            Loaded += OrderEntry_Loaded;
        }

        // ─── WINDOW LIFECYCLE ────────────────────────────────
        private void OrderEntry_Loaded(object sender, RoutedEventArgs e)
        {
            txtCashierName.Text = _cashierName;
            txtDateTime.Text = DateTime.Now.ToString("dd/MM/yyyy hh:mm tt");

            LoadMenuItems();
            LoadTables();
            LoadActiveOrders();
            StartNewOrder();
        }

        private void ClockTimer_Tick(object? sender, EventArgs e)
        {
            txtDateTime.Text = DateTime.Now.ToString("dd/MM/yyyy hh:mm tt");
        }

        // ─── MENU ITEMS ──────────────────────────────────────
        private void LoadMenuItems()
        {
            try
            {
                _allMenuItems = DatabaseService.Instance.GetMenuItems();
                _filteredMenuItems = new List<MenuItem>(_allMenuItems);
                ApplyPagination();
            }
            catch (Exception ex)
            {
                LoadDemoMenuItems();
            }
        }

        private void LoadDemoMenuItems()
        {
            _allMenuItems = new List<MenuItem>
            {
                new() { ItemId = 1, ItemName = "Jollof Rice", BasePrice = 3500, Stock = 45, Category = "Main Dishes" },
                new() { ItemId = 2, ItemName = "Fried Rice", BasePrice = 3500, Stock = 38, Category = "Main Dishes" },
                new() { ItemId = 3, ItemName = "White Rice", BasePrice = 2500, Stock = 50, Category = "Main Dishes" },
                new() { ItemId = 4, ItemName = "Chicken", BasePrice = 4000, Stock = 25, Category = "Grills" },
                new() { ItemId = 5, ItemName = "Beef", BasePrice = 3500, Stock = 32, Category = "Grills" },
                new() { ItemId = 6, ItemName = "Goat Meat", BasePrice = 4500, Stock = 20, Category = "Grills" },
                new() { ItemId = 7, ItemName = "Grilled Fish", BasePrice = 4000, Stock = 18, Category = "Grills" },
                new() { ItemId = 8, ItemName = "Pepper Soup", BasePrice = 3000, Stock = 25, Category = "Main Dishes" },
                new() { ItemId = 9, ItemName = "Chicken Wings", BasePrice = 3500, Stock = 30, Category = "Grills" },
                new() { ItemId = 10, ItemName = "Shawarma", BasePrice = 3000, Stock = 18, Category = "Shawarma" },
                new() { ItemId = 11, ItemName = "Spaghetti Pasta", BasePrice = 3500, Stock = 22, Category = "Main Dishes" },
                new() { ItemId = 12, ItemName = "Pizza", BasePrice = 8500, Stock = 12, Category = "Main Dishes" },
                new() { ItemId = 13, ItemName = "French Fries", BasePrice = 1500, Stock = 40, Category = "Sides" },
                new() { ItemId = 14, ItemName = "Fresh Orange Juice", BasePrice = 3000, Stock = 20, Category = "Drinks" },
                new() { ItemId = 15, ItemName = "Mango Juice", BasePrice = 3000, Stock = 15, Category = "Drinks" },
                new() { ItemId = 16, ItemName = "Bottled Water", BasePrice = 500, Stock = 100, Category = "Drinks" },
                new() { ItemId = 17, ItemName = "Coca Cola 50cl", BasePrice = 800, Stock = 60, Category = "Drinks" },
                new() { ItemId = 18, ItemName = "Fanta 50cl", BasePrice = 800, Stock = 60, Category = "Drinks" }
            };
            _filteredMenuItems = new List<MenuItem>(_allMenuItems);
            ApplyPagination();
        }

        private void ApplyPagination()
        {
            _totalPages = Math.Max(1, (int)Math.Ceiling(_filteredMenuItems.Count / (double)_pageSize));
            if (_currentPage > _totalPages) _currentPage = _totalPages;
            if (_currentPage < 1) _currentPage = 1;

            var pageItems = _filteredMenuItems
                .Skip((_currentPage - 1) * _pageSize)
                .Take(_pageSize)
                .ToList();

            RenderMenuItems(pageItems);
            UpdatePaginationUI();
        }

        private void RenderMenuItems(List<MenuItem> items)
        {
            MenuItemsPanel.Children.Clear();
            foreach (var item in items)
            {
                var row = new Grid { Height = 40, Cursor = Cursors.Hand };
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });

                var nameBlock = new TextBlock
                {
                    Text = item.ItemName,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B")),
                    FontSize = 13,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(16, 0, 0, 0)
                };

                var priceBlock = new TextBlock
                {
                    Text = $"N{item.BasePrice:N0}",
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B")),
                    FontSize = 13,
                    VerticalAlignment = VerticalAlignment.Center
                };

                var stockBlock = new TextBlock
                {
                    Text = item.Stock.ToString(),
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#64748B")),
                    FontSize = 13,
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center
                };

                Grid.SetColumn(nameBlock, 0);
                Grid.SetColumn(priceBlock, 1);
                Grid.SetColumn(stockBlock, 2);

                row.Children.Add(nameBlock);
                row.Children.Add(priceBlock);
                row.Children.Add(stockBlock);

                if (MenuItemsPanel.Children.Count % 2 == 1)
                    row.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F8FAFC"));

                row.MouseLeftButtonDown += (s, e) => AddItemToOrder(item);
                row.MouseEnter += (s, e) => row.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F1F5F9"));
                row.MouseLeave += (s, e) =>
                {
                    int idx = MenuItemsPanel.Children.IndexOf(row);
                    row.Background = idx % 2 == 1
                        ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F8FAFC"))
                        : Brushes.White;
                };

                MenuItemsPanel.Children.Add(row);
            }
        }

        private void UpdatePaginationUI()
        {
            txtPaginationInfo.Text = $"{_currentPage} - {_totalPages} of {_filteredMenuItems.Count} items";

            var parent = btnPage1.Parent as StackPanel;
            if (parent != null)
            {
                foreach (var child in parent.Children)
                {
                    if (child is Button btn && btn.Name != null && btn.Name.StartsWith("btnPage"))
                    {
                        btn.Background = Brushes.White;
                        btn.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B"));
                        btn.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#E2E8F0"));
                        btn.BorderThickness = new Thickness(1);
                    }
                }
            }

            Button? currentBtn = _currentPage switch
            {
                1 => btnPage1,
                2 => btnPage2,
                3 => btnPage3,
                4 => btnPage4,
                5 => btnPage5,
                _ => null
            };

            if (currentBtn != null)
            {
                currentBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#059669"));
                currentBtn.Foreground = Brushes.White;
                currentBtn.BorderThickness = new Thickness(0);
            }
        }

        // ─── CATEGORY TABS ───────────────────────────────────
        private void CategoryTab_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn) return;

            foreach (var child in CategoryTabsPanel.Children)
            {
                if (child is Button b)
                    b.Tag = null;
            }

            btn.Tag = "Selected";
            _currentCategory = btn.Content?.ToString() ?? "All Items";
            _currentPage = 1;

            if (_currentCategory == "All Items")
                _filteredMenuItems = new List<MenuItem>(_allMenuItems);
            else
                _filteredMenuItems = _allMenuItems.Where(m => m.Category == _currentCategory).ToList();

            ApplyPagination();
        }

        // ─── TABLES ──────────────────────────────────────────
        private void LoadTables()
        {
            try
            {
                _tables = DatabaseService.Instance.GetTables(_outletId);
            }
            catch
            {
                _tables = new List<Table>();
                for (int i = 1; i <= 20; i++)
                {
                    var status = i switch
                    {
                        2 or 3 or 7 or 9 or 13 or 17 => TableStatus.Occupied,
                        4 or 11 or 19 => TableStatus.Unpaid,
                        15 => TableStatus.Reserved,
                        _ => TableStatus.Available
                    };

                    var total = status == TableStatus.Occupied || status == TableStatus.Unpaid
                        ? new decimal[] { 7500, 12000, 5000, 15000, 8000, 13000, 4500, 9500, 18500 }[(i * 7) % 9]
                        : 0;

                    _tables.Add(new Table
                    {
                        TableId = i,
                        TableNumber = $"T{i}",
                        Status = status,
                        CurrentTotal = total,
                        CurrentOrderNumber = total > 0 ? $"ORD-{DateTime.Now:yyyyMMdd}-{(i * 3 + 100):D5}" : ""
                    });
                }
            }

            RenderTables();
        }

        private void RenderTables()
        {
            TablesWrapPanel.Children.Clear();
            foreach (var table in _tables)
            {
                var btn = new Button
                {
                    Tag = table.TableNumber,
                    Content = table.DisplayTotal,
                    Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(table.StatusColor)),
                    Style = (Style)FindResource("TableButton")
                };

                if (_selectedTable?.TableNumber == table.TableNumber)
                {
                    btn.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F59E0B"));
                    btn.BorderThickness = new Thickness(2);
                }

                btn.Click += (s, e) => SelectTable(table);
                TablesWrapPanel.Children.Add(btn);
            }
        }

        private void SelectTable(Table table)
        {
            _selectedTable = table;
            txtSelectedTable.Text = table.TableNumber;
            selectedTableIndicator.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(table.StatusColor));
            txtTableStatus.Text = table.StatusText;
            txtTableStatus.Foreground = table.Status == TableStatus.Unpaid
                ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#92400E"))
                : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B"));
            ((Border)txtTableStatus.Parent).Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(table.StatusColor));
            txtCurrentOrderNo.Text = table.CurrentOrderNumber;
            txtTableTotal.Text = table.DisplayTotal;
            txtTableCustomer.Text = "Walk-in Customer";
            txtCurrentOrderTable.Text = $"(Table: {table.TableNumber})";

            RenderTables();
        }

        // ─── ACTIVE ORDERS ───────────────────────────────────
        private void LoadActiveOrders()
        {
            try
            {
                _activeOrders = DatabaseService.Instance.GetActiveOrders(_outletId);
            }
            catch
            {
                _activeOrders = new List<Order>();
            }
            RenderActiveOrders();
        }

        private void RenderActiveOrders()
        {
            ActiveOrdersPanel.Children.Clear();
            foreach (var order in _activeOrders)
            {
                var grid = new Grid { Margin = new Thickness(0, 4) };
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(30) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(50) });

                var tableBlock = new TextBlock
                {
                    Text = order.TableNumber,
                    FontWeight = FontWeights.SemiBold,
                    FontSize = 12,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B"))
                };

                var orderBlock = new TextBlock
                {
                    Text = order.OrderNumber,
                    FontSize = 11,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#64748B")),
                    Margin = new Thickness(4, 0, 0, 0)
                };

                var totalBlock = new TextBlock
                {
                    Text = $"N{order.TotalAmount:N2}",
                    FontSize = 12,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B")),
                    HorizontalAlignment = HorizontalAlignment.Right
                };

                var viewBtn = new Button
                {
                    Content = "View",
                    FontSize = 10,
                    Padding = new Thickness(6, 2, 6, 2),
                    Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F1F5F9")),
                    BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#E2E8F0")),
                    BorderThickness = new Thickness(1),
                    Cursor = Cursors.Hand,
                    Margin = new Thickness(4, 0, 0, 0)
                };
                viewBtn.Click += (s, e) => LoadOrder(order);

                Grid.SetColumn(tableBlock, 0);
                Grid.SetColumn(orderBlock, 1);
                Grid.SetColumn(totalBlock, 2);
                Grid.SetColumn(viewBtn, 3);

                grid.Children.Add(tableBlock);
                grid.Children.Add(orderBlock);
                grid.Children.Add(totalBlock);
                grid.Children.Add(viewBtn);

                if (_selectedTable != null && order.TableNumber == _selectedTable.TableNumber)
                {
                    grid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FEF3C7"));
                    grid.Margin = new Thickness(-4, 4, -4, 4);
                    grid.Padding = new Thickness(4);
                }

                ActiveOrdersPanel.Children.Add(grid);
            }
        }

        private void LoadOrder(Order order)
        {
            _currentOrder = order;
            txtOrderNumber.Text = order.OrderNumber;
            RefreshOrderDisplay();
        }

        // ─── ORDER MANAGEMENT ──────────────────────────────────
        private void StartNewOrder()
        {
            _currentOrder = new Order
            {
                OrderNumber = GenerateOrderNumber(),
                BranchId = _branchId,
                OutletId = _outletId,
                CashierName = _cashierName,
                TableNumber = _selectedTable?.TableNumber ?? "",
                Status = OrderStatus.Pending,
                OrderTime = DateTime.Now
            };

            txtOrderNumber.Text = _currentOrder.OrderNumber;
            RefreshOrderDisplay();
        }

        private string GenerateOrderNumber()
        {
            try
            {
                return DatabaseService.Instance.GetNextOrderNumber();
            }
            catch
            {
                return $"ORD-{DateTime.Now:yyyyMMdd}-{new Random().Next(10000, 99999)}";
            }
        }

        private void AddItemToOrder(MenuItem menuItem)
        {
            if (menuItem.Stock <= 0)
            {
                MessageBox.Show($"{menuItem.ItemName} is out of stock!", "Stock Alert", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var existing = _currentOrder.Items.FirstOrDefault(i => i.ItemId == menuItem.ItemId);
            if (existing != null)
            {
                existing.Quantity += 1;
            }
            else
            {
                var orderItem = new OrderItem
                {
                    OrderItemId = _currentOrder.Items.Count + 1,
                    ItemId = menuItem.ItemId,
                    MenuItem = menuItem,
                    ItemNumber = _currentOrder.Items.Count + 1,
                    Quantity = 1,
                    UnitPrice = menuItem.BasePrice,
                    TaxAmount = menuItem.BasePrice * 0.075m
                };
                _currentOrder.Items.Add(orderItem);
            }

            menuItem.Stock -= 1;
            RefreshOrderDisplay();
            ApplyPagination();
        }

        private void RefreshOrderDisplay()
        {
            OrderItemsPanel.Children.Clear();
            int idx = 1;
            foreach (var item in _currentOrder.Items)
            {
                var grid = new Grid { Height = 44, Margin = new Thickness(8, 2, 8, 2) };
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(24) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(90) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(24) });

                var numBlock = new TextBlock
                {
                    Text = idx.ToString(),
                    FontSize = 12,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#64748B")),
                    VerticalAlignment = VerticalAlignment.Center
                };

                var nameBlock = new TextBlock
                {
                    Text = item.DisplayName,
                    FontSize = 12,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B")),
                    VerticalAlignment = VerticalAlignment.Center,
                    TextTrimming = TextTrimming.CharacterEllipsis
                };

                var qtyPanel = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
                var minusBtn = new Button
                {
                    Content = "-",
                    Style = (Style)FindResource("QtyButton"),
                    Tag = item
                };
                minusBtn.Click += (s, e) =>
                {
                    if (item.Quantity > 1)
                    {
                        item.Quantity -= 1;
                        if (item.MenuItem != null) item.MenuItem.Stock += 1;
                    }
                    else
                    {
                        RemoveItemFromOrder(item);
                        return;
                    }
                    RefreshOrderDisplay();
                    ApplyPagination();
                };

                var qtyBlock = new TextBlock
                {
                    Text = item.Quantity.ToString("F0"),
                    Width = 28,
                    TextAlignment = TextAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    FontSize = 13,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B"))
                };

                var plusBtn = new Button
                {
                    Content = "+",
                    Style = (Style)FindResource("QtyButton"),
                    Tag = item
                };
                plusBtn.Click += (s, e) =>
                {
                    if (item.MenuItem != null && item.MenuItem.Stock > 0)
                    {
                        item.Quantity += 1;
                        item.MenuItem.Stock -= 1;
                        RefreshOrderDisplay();
                        ApplyPagination();
                    }
                };

                qtyPanel.Children.Add(minusBtn);
                qtyPanel.Children.Add(qtyBlock);
                qtyPanel.Children.Add(plusBtn);

                var priceBlock = new TextBlock
                {
                    Text = item.DisplayPrice,
                    FontSize = 12,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B")),
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Right
                };

                var totalBlock = new TextBlock
                {
                    Text = item.DisplayTotal,
                    FontSize = 12,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B")),
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Right
                };

                var removeBtn = new Button
                {
                    Content = "x",
                    Style = (Style)FindResource("RemoveBtn"),
                    Tag = item
                };
                removeBtn.Click += (s, e) => RemoveItemFromOrder(item);

                Grid.SetColumn(numBlock, 0);
                Grid.SetColumn(nameBlock, 1);
                Grid.SetColumn(qtyPanel, 2);
                Grid.SetColumn(priceBlock, 3);
                Grid.SetColumn(totalBlock, 4);
                Grid.SetColumn(removeBtn, 5);

                grid.Children.Add(numBlock);
                grid.Children.Add(nameBlock);
                grid.Children.Add(qtyPanel);
                grid.Children.Add(priceBlock);
                grid.Children.Add(totalBlock);
                grid.Children.Add(removeBtn);

                if (idx % 2 == 0)
                    grid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F8FAFC"));

                OrderItemsPanel.Children.Add(grid);
                idx++;
            }

            _currentOrder.Recalculate();
            txtItemCount.Text = $"{_currentOrder.Items.Count} Items";
            txtSubtotal.Text = _currentOrder.DisplaySubtotal;
            txtVAT.Text = _currentOrder.DisplayVAT;
            txtTotal.Text = _currentOrder.DisplayTotal;
        }

        private void RemoveItemFromOrder(OrderItem item)
        {
            if (item.MenuItem != null)
                item.MenuItem.Stock += (int)item.Quantity;

            _currentOrder.Items.Remove(item);
            RefreshOrderDisplay();
            ApplyPagination();
        }

        private void ClearOrder_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Clear all items from current order?", "Confirm",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            foreach (var item in _currentOrder.Items)
            {
                if (item.MenuItem != null)
                    item.MenuItem.Stock += (int)item.Quantity;
            }
            _currentOrder.Items.Clear();
            _currentOrder.DiscountAmount = 0;
            txtDiscount.Text = "0.00";
            RefreshOrderDisplay();
            ApplyPagination();
        }

        private void txtDiscount_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (decimal.TryParse(txtDiscount.Text.Replace(",", "").Replace("N", ""), out var discount))
            {
                _currentOrder.DiscountAmount = discount;
                _currentOrder.Recalculate();
                txtSubtotal.Text = _currentOrder.DisplaySubtotal;
                txtVAT.Text = _currentOrder.DisplayVAT;
                txtTotal.Text = _currentOrder.DisplayTotal;
            }
        }

        // ─── BILL ────────────────────────────────────────────
        private void BillButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentOrder.Items.Count == 0)
            {
                MessageBox.Show("No items in order to bill.", "Empty Order", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SaveCurrentOrderToDatabase();

            var bill = new Bill
            {
                BillNo = GenerateBillNumber(),
                OrderId = _currentOrder.OrderId,
                BranchId = _branchId,
                OutletId = _outletId,
                TableId = _selectedTable?.TableId,
                TableNumber = _selectedTable?.TableNumber ?? "",
                CashierId = _cashierId,
                Subtotal = _currentOrder.SubTotal,
                TaxAmount = _currentOrder.TaxAmount,
                ServiceCharge = _currentOrder.ServiceCharge,
                DiscountAmount = _currentOrder.DiscountAmount,
                TotalAmount = _currentOrder.TotalAmount,
                BalanceDue = _currentOrder.TotalAmount,
                BillStatus = BillStatus.Printed,
                BillDate = DateTime.Now,
                BillTime = DateTime.Now.TimeOfDay,
                PrintCount = 1,
                IsCleared = false,
                Notes = $"Bill printed for Table {_selectedTable?.TableNumber}. Table not yet cleared."
            };

            try
            {
                int billId = DatabaseService.Instance.SaveBill(bill);
                bill.BillId = billId;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"DB save failed: {ex.Message}");
            }

            _currentOrder.HasUnclearedBill = true;
            _currentOrder.BillPrintedAt = DateTime.Now;

            if (_selectedTable != null)
            {
                _selectedTable.Status = TableStatus.Unpaid;
                _selectedTable.CurrentTotal = _currentOrder.TotalAmount;
                _selectedTable.CurrentOrderNumber = _currentOrder.OrderNumber;
                RenderTables();
                SelectTable(_selectedTable);
            }

            var preview = new BillPreviewWindow(bill, _currentOrder);
            preview.Owner = this;
            preview.ShowDialog();

            LoadActiveOrders();
        }

        private string GenerateBillNumber()
        {
            try
            {
                return DatabaseService.Instance.GetNextBillNumber();
            }
            catch
            {
                return $"BILL-{DateTime.Now:yyyyMMdd}-{new Random().Next(10000, 99999)}";
            }
        }

        // ─── DOCKET ────────────────────────────────────────────
        private void DocketButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentOrder.Items.Count == 0)
            {
                MessageBox.Show("No items in order to docket.", "Empty Order", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SaveCurrentOrderToDatabase();
            _currentOrder.DocketPrintedAt = DateTime.Now;

            var docketWindow = new DocketPreviewWindow(_currentOrder);
            docketWindow.Owner = this;
            docketWindow.ShowDialog();
        }

        // ─── SAVE ORDER ──────────────────────────────────────
        private void SaveOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentOrder.Items.Count == 0)
            {
                MessageBox.Show("No items to save.", "Empty Order", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SaveCurrentOrderToDatabase();
            MessageBox.Show("Order saved successfully!", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SaveCurrentOrderToDatabase()
        {
            try
            {
                if (_currentOrder.OrderId == 0)
                {
                    _currentOrder.TableId = _selectedTable?.TableId;
                    int orderId = DatabaseService.Instance.SaveOrder(_currentOrder);
                }
                else
                {
                    DatabaseService.Instance.UpdateOrder(_currentOrder);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Save error: {ex.Message}");
            }
        }

        // ─── CANCEL ORDER ────────────────────────────────────
        private void CancelOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentOrder.Items.Count == 0)
            {
                MessageBox.Show("No active order to cancel.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (MessageBox.Show("Are you sure you want to cancel this order?", "Confirm Cancel",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            try
            {
                if (_currentOrder.OrderId > 0)
                    DatabaseService.Instance.CancelOrder(_currentOrder.OrderId);
            }
            catch { }

            foreach (var item in _currentOrder.Items)
            {
                if (item.MenuItem != null)
                    item.MenuItem.Stock += (int)item.Quantity;
            }

            _currentOrder.Items.Clear();
            _currentOrder.DiscountAmount = 0;
            txtDiscount.Text = "0.00";
            RefreshOrderDisplay();
            ApplyPagination();
            StartNewOrder();
            LoadActiveOrders();
        }

        // ─── PAY ───────────────────────────────────────────────
        private void PayButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentOrder.Items.Count == 0)
            {
                MessageBox.Show("No items to pay for.", "Empty Order", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SaveCurrentOrderToDatabase();

            var paymentWindow = new PaymentWindow
            {
                OrderTotal = _currentOrder.TotalAmount,
                OrderNumber = _currentOrder.OrderNumber,
                CurrentUserName = _cashierName,
                Owner = this
            };

            if (paymentWindow.ShowDialog() == true)
            {
                try
                {
                    // Mark uncleared bills as cleared
                }
                catch { }

                if (_selectedTable != null)
                {
                    _selectedTable.Status = TableStatus.Available;
                    _selectedTable.CurrentTotal = 0;
                    _selectedTable.CurrentOrderNumber = "";
                    RenderTables();
                }

                _currentOrder.Items.Clear();
                _currentOrder.DiscountAmount = 0;
                txtDiscount.Text = "0.00";
                RefreshOrderDisplay();
                ApplyPagination();
                StartNewOrder();
                LoadActiveOrders();

                MessageBox.Show("Payment completed successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // ─── CHANGE TABLE ────────────────────────────────────
        private void ChangeTableButton_Click(object sender, RoutedEventArgs e)
        {
            var availableTables = _tables.Where(t => t.Status == TableStatus.Available || t.TableNumber == _selectedTable?.TableNumber).ToList();
            if (availableTables.Count == 0)
            {
                MessageBox.Show("No available tables.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new Window
            {
                Title = "Select Table",
                Width = 400,
                Height = 300,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F8FAFC"))
            };

            var panel = new StackPanel { Margin = new Thickness(16) };
            panel.Children.Add(new TextBlock { Text = "Select New Table", FontWeight = FontWeights.Bold, FontSize = 16, Margin = new Thickness(0, 0, 0, 12) });

            var listBox = new ListBox { Margin = new Thickness(0, 0, 0, 12) };
            foreach (var t in availableTables)
            {
                listBox.Items.Add($"{t.TableNumber} - {t.TableName} (Capacity: {t.Capacity})");
            }
            panel.Children.Add(listBox);

            var btnPanel = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            var okBtn = new Button { Content = "OK", Width = 80, Height = 32, Margin = new Thickness(0, 0, 8, 0), Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#10B981")), Foreground = Brushes.White, BorderThickness = new Thickness(0) };
            var cancelBtn = new Button { Content = "Cancel", Width = 80, Height = 32, Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F1F5F9")), BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#E2E8F0")) };

            okBtn.Click += (s, ev) =>
            {
                if (listBox.SelectedIndex >= 0)
                {
                    var newTable = availableTables[listBox.SelectedIndex];
                    var oldTableId = _selectedTable?.TableId;

                    try
                    {
                        if (_currentOrder.OrderId > 0)
                            DatabaseService.Instance.ChangeTable(_currentOrder.OrderId, newTable.TableId, oldTableId);
                    }
                    catch { }

                    _selectedTable = newTable;
                    _currentOrder.TableNumber = newTable.TableNumber;
                    txtCurrentOrderTable.Text = $"(Table: {newTable.TableNumber})";
                    SelectTable(newTable);
                    dialog.Close();
                }
            };

            cancelBtn.Click += (s, ev) => dialog.Close();
            btnPanel.Children.Add(okBtn);
            btnPanel.Children.Add(cancelBtn);
            panel.Children.Add(btnPanel);

            dialog.Content = panel;
            dialog.ShowDialog();
        }

        // ─── SEARCH ────────────────────────────────────────────
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            txtSearchPlaceholder.Visibility = string.IsNullOrWhiteSpace(txtSearch.Text)
                ? Visibility.Visible : Visibility.Collapsed;

            var query = txtSearch.Text.ToLower();
            if (string.IsNullOrWhiteSpace(query))
            {
                _filteredMenuItems = _currentCategory == "All Items"
                    ? new List<MenuItem>(_allMenuItems)
                    : _allMenuItems.Where(m => m.Category == _currentCategory).ToList();
            }
            else
            {
                _filteredMenuItems = _allMenuItems
                    .Where(m => m.ItemName.ToLower().Contains(query) ||
                                m.ItemCode.ToLower().Contains(query) ||
                                m.Barcode.ToLower().Contains(query))
                    .ToList();
            }

            _currentPage = 1;
            ApplyPagination();
        }

        private void txtSearch_GotFocus(object sender, RoutedEventArgs e)
        {
            txtSearchPlaceholder.Visibility = Visibility.Collapsed;
        }

        private void txtSearch_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
                txtSearchPlaceholder.Visibility = Visibility.Visible;
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            txtSearch.Focus();
        }

        // ─── PAGINATION ──────────────────────────────────────
        private void FirstPage_Click(object sender, RoutedEventArgs e)
        {
            _currentPage = 1;
            ApplyPagination();
        }

        private void PrevPage_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage > 1) { _currentPage--; ApplyPagination(); }
        }

        private void PageNumber_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && int.TryParse(btn.Content?.ToString(), out int page))
            {
                _currentPage = page;
                ApplyPagination();
            }
        }

        private void NextPage_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage < _totalPages) { _currentPage++; ApplyPagination(); }
        }

        private void LastPage_Click(object sender, RoutedEventArgs e)
        {
            _currentPage = _totalPages;
            ApplyPagination();
        }

        // ─── HEADER BUTTONS ──────────────────────────────────
        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Return to Admin Dashboard?", "Menu", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                var main = new MainWindow();
                main.Show();
                Close();
            }
        }

        private void ExpandButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Confirm Logout",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }

        private void ViewAllOrders_Click(object sender, RoutedEventArgs e)
        {
            LoadActiveOrders();
            MessageBox.Show($"Total active orders: {_activeOrders.Count}", "Active Orders", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // ─── KEYBOARD SHORTCUTS ──────────────────────────────
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.F1:
                    StartNewOrder();
                    e.Handled = true;
                    break;
                case Key.F2:
                    txtSearch.Focus();
                    e.Handled = true;
                    break;
                case Key.F3:
                    ChangeTableButton_Click(sender, e);
                    e.Handled = true;
                    break;
                case Key.F4:
                    DocketButton_Click(sender, e);
                    e.Handled = true;
                    break;
                case Key.F5:
                    BillButton_Click(sender, e);
                    e.Handled = true;
                    break;
                case Key.F6:
                    SaveOrderButton_Click(sender, e);
                    e.Handled = true;
                    break;
                case Key.F7:
                    PayButton_Click(sender, e);
                    e.Handled = true;
                    break;
                case Key.F12:
                    CancelOrderButton_Click(sender, e);
                    e.Handled = true;
                    break;
            }
        }
    }
}
