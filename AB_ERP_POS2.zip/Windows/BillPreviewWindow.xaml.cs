using System;
using System.IO;
using System.IO.Packaging;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Xps;
using System.Windows.Xps.Packaging;
using AB_ERP_POS2.Models;

namespace AB_ERP_POS2.Windows
{
    public partial class BillPreviewWindow : Window
    {
        private readonly Bill _bill;
        private readonly Order _order;

        public BillPreviewWindow(Bill bill, Order order)
        {
            InitializeComponent();
            _bill = bill;
            _order = order;
            Loaded += BillPreviewWindow_Loaded;
        }

        private void BillPreviewWindow_Loaded(object sender, RoutedEventArgs e)
        {
            txtBillNo.Text = _bill.BillNo;
            txtBillDate.Text = _bill.BillDate.ToString("dd/MM/yyyy hh:mm tt");
            txtBillTable.Text = _bill.TableNumber;
            txtBillCashier.Text = _order.CashierName;
            txtBillSubtotal.Text = $"N{_bill.Subtotal:N2}";
            txtBillDiscount.Text = $"N{_bill.DiscountAmount:N2}";
            txtBillVAT.Text = $"N{_bill.TaxAmount:N2}";
            txtBillTotal.Text = $"N{_bill.TotalAmount:N2}";

            // Render items
            BillItemsPanel.Children.Clear();
            foreach (var item in _order.Items)
            {
                var grid = new Grid { Margin = new Thickness(0, 4) };
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(50) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });

                var name = new TextBlock
                {
                    Text = item.DisplayName,
                    FontSize = 12,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B"))
                };
                var qty = new TextBlock
                {
                    Text = item.Quantity.ToString("F0"),
                    FontSize = 12,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#64748B"))
                };
                var price = new TextBlock
                {
                    Text = $"N{item.UnitPrice:N2}",
                    FontSize = 12,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#64748B"))
                };
                var total = new TextBlock
                {
                    Text = item.DisplayTotal,
                    FontSize = 12,
                    FontWeight = FontWeights.SemiBold,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B"))
                };

                Grid.SetColumn(name, 0);
                Grid.SetColumn(qty, 1);
                Grid.SetColumn(price, 2);
                Grid.SetColumn(total, 3);

                grid.Children.Add(name);
                grid.Children.Add(qty);
                grid.Children.Add(price);
                grid.Children.Add(total);

                BillItemsPanel.Children.Add(grid);
            }
        }

        private void QuickPrint_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var printDialog = new PrintDialog();
                printDialog.PrintTicket.PageOrientation = PageOrientation.Portrait;

                // Print directly without showing dialog
                printDialog.PrintVisual(BillContent, $"Bill {_bill.BillNo}");

                // Update print count
                try
                {
                    Services.DatabaseService.Instance.UpdateBillPrintCount(_bill.BillId);
                }
                catch { }

                MessageBox.Show("Bill printed successfully!", "Print", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Print failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void PrintDialog_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var printDialog = new PrintDialog();
                printDialog.PrintTicket.PageOrientation = PageOrientation.Portrait;

                if (printDialog.ShowDialog() == true)
                {
                    printDialog.PrintVisual(BillContent, $"Bill {_bill.BillNo}");

                    try
                    {
                        Services.DatabaseService.Instance.UpdateBillPrintCount(_bill.BillId);
                    }
                    catch { }

                    MessageBox.Show("Bill printed successfully!", "Print", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Print failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SavePDF_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dialog = new Microsoft.Win32.SaveFileDialog
                {
                    FileName = $"Bill_{_bill.BillNo}.xps",
                    DefaultExt = ".xps",
                    Filter = "XPS Documents (.xps)|*.xps"
                };

                if (dialog.ShowDialog() == true)
                {
                    SaveVisualToXps(BillContent, dialog.FileName);
                    MessageBox.Show($"Bill saved to: {dialog.FileName}", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Save failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveVisualToXps(Visual visual, string filePath)
        {
            using var package = Package.Open(filePath, FileMode.Create);
            var doc = new XpsDocument(package, CompressionOption.Maximum);
            var writer = XpsDocument.CreateXpsDocumentWriter(doc);
            writer.Write(visual);
            doc.Close();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
