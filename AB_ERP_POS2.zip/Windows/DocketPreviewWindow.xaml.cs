using System;
using System.IO;
using System.IO.Packaging;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Xps;
using System.Windows.Xps.Packaging;
using AB_ERP_POS2.Models;

namespace AB_ERP_POS2.Windows
{
    public partial class DocketPreviewWindow : Window
    {
        private readonly Order _order;

        public DocketPreviewWindow(Order order)
        {
            InitializeComponent();
            _order = order;
            Loaded += DocketPreviewWindow_Loaded;
        }

        private void DocketPreviewWindow_Loaded(object sender, RoutedEventArgs e)
        {
            txtDocketOrderNo.Text = _order.OrderNumber;
            txtDocketTable.Text = _order.TableNumber;
            txtDocketTime.Text = _order.OrderTime.ToString("hh:mm tt");
            txtDocketCashier.Text = _order.CashierName;
            txtDocketGuests.Text = _order.GuestCount.ToString();
            txtDocketNotes.Text = string.IsNullOrWhiteSpace(_order.SpecialInstructions) ? "None" : _order.SpecialInstructions;

            DocketItemsPanel.Children.Clear();
            foreach (var item in _order.Items)
            {
                var grid = new Grid { Margin = new Thickness(0, 6) };
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(50) });

                var qty = new TextBlock
                {
                    Text = item.Quantity.ToString("F0"),
                    FontSize = 14,
                    FontWeight = FontWeights.Bold,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B"))
                };

                var name = new TextBlock
                {
                    Text = item.DisplayName,
                    FontSize = 13,
                    FontWeight = FontWeights.SemiBold,
                    Margin = new Thickness(8, 0, 0, 0),
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1E293B"))
                };

                var status = new TextBlock
                {
                    Text = "Pending",
                    FontSize = 11,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F59E0B"))
                };

                Grid.SetColumn(qty, 0);
                Grid.SetColumn(name, 1);
                Grid.SetColumn(status, 2);

                grid.Children.Add(qty);
                grid.Children.Add(name);
                grid.Children.Add(status);

                DocketItemsPanel.Children.Add(grid);
            }
        }

        private void QuickPrint_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var printDialog = new PrintDialog();
                printDialog.PrintTicket.PageOrientation = PageOrientation.Portrait;
                printDialog.PrintVisual(DocketContent, $"Docket {_order.OrderNumber}");
                MessageBox.Show("Docket printed successfully!", "Print", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Print failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void PrintDialog_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var printDialog = new PrintDialog();
                printDialog.PrintTicket.PageOrientation = PageOrientation.Portrait;

                if (printDialog.ShowDialog() == true)
                {
                    printDialog.PrintVisual(DocketContent, $"Docket {_order.OrderNumber}");
                    MessageBox.Show("Docket printed successfully!", "Print", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Print failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
