using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using System.Windows;
using MySqlConnector;
using AB_ERP_POS2.Models;

namespace AB_ERP_POS2.Services
{
    public class DatabaseService
    {
        private readonly string _connectionString;
        private static DatabaseService? _instance;
        public static DatabaseService Instance => _instance ??= new DatabaseService();

        public DatabaseService()
        {
            // Update with your actual connection string
            _connectionString = "Server=localhost;Database=AB_ERP;Uid=root;Pwd=your_password;Port=3306;";
        }

        public DatabaseService(string connectionString)
        {
            _connectionString = connectionString;
        }

        private MySqlConnection GetConnection() => new MySqlConnection(_connectionString);

        // ===================== MENU ITEMS =====================
        public List<MenuItem> GetMenuItems(int? categoryId = null)
        {
            var items = new List<MenuItem>();
            using var conn = GetConnection();
            conn.Open();

            string sql = @"
                SELECT mi.item_id, mi.category_id, mi.item_code, mi.item_name, mi.short_name,
                       mi.description, mi.barcode, mi.cost_price, mi.base_price, mi.tax_id,
                       mi.preparation_time, mi.is_food, mi.is_beverage, mi.is_alcoholic,
                       mi.is_combo, mi.has_recipe, mi.is_active,
                       COALESCE(sb.quantity_available, 100) as stock,
                       mc.category_name as category
                FROM menu_items mi
                LEFT JOIN menu_categories mc ON mi.category_id = mc.category_id
                LEFT JOIN stock_balance sb ON mi.item_id = sb.item_id
                WHERE mi.is_active = TRUE";

            if (categoryId.HasValue)
                sql += " AND mi.category_id = @catId";

            sql += " ORDER BY mi.item_name";

            using var cmd = new MySqlCommand(sql, conn);
            if (categoryId.HasValue)
                cmd.Parameters.AddWithValue("@catId", categoryId.Value);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                items.Add(new MenuItem
                {
                    ItemId = reader.GetInt32("item_id"),
                    CategoryId = reader.GetInt32("category_id"),
                    ItemCode = reader.GetString("item_code"),
                    ItemName = reader.GetString("item_name"),
                    ShortName = reader.IsDBNull("short_name") ? "" : reader.GetString("short_name"),
                    Description = reader.IsDBNull("description") ? "" : reader.GetString("description"),
                    Barcode = reader.IsDBNull("barcode") ? "" : reader.GetString("barcode"),
                    CostPrice = reader.GetDecimal("cost_price"),
                    BasePrice = reader.GetDecimal("base_price"),
                    TaxId = reader.GetInt32("tax_id"),
                    PreparationTime = reader.GetInt32("preparation_time"),
                    IsFood = reader.GetBoolean("is_food"),
                    IsBeverage = reader.GetBoolean("is_beverage"),
                    IsAlcoholic = reader.GetBoolean("is_alcoholic"),
                    IsCombo = reader.GetBoolean("is_combo"),
                    HasRecipe = reader.GetBoolean("has_recipe"),
                    IsActive = reader.GetBoolean("is_active"),
                    Stock = reader.IsDBNull("stock") ? 100 : reader.GetInt32("stock"),
                    Category = reader.IsDBNull("category") ? "All Items" : reader.GetString("category")
                });
            }
            return items;
        }

        // ===================== CATEGORIES =====================
        public List<MenuCategory> GetCategories()
        {
            var cats = new List<MenuCategory>();
            using var conn = GetConnection();
            conn.Open();

            using var cmd = new MySqlCommand(
                "SELECT category_id, parent_category_id, category_name, description, is_active FROM menu_categories WHERE is_active = TRUE ORDER BY display_order, category_name",
                conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                cats.Add(new MenuCategory
                {
                    CategoryId = reader.GetInt32("category_id"),
                    ParentCategoryId = reader.IsDBNull("parent_category_id") ? null : reader.GetInt32("parent_category_id"),
                    CategoryName = reader.GetString("category_name"),
                    Description = reader.IsDBNull("description") ? "" : reader.GetString("description"),
                    IsActive = reader.GetBoolean("is_active")
                });
            }
            return cats;
        }

        // ===================== TABLES =====================
        public List<Table> GetTables(int outletId)
        {
            var tables = new List<Table>();
            using var conn = GetConnection();
            conn.Open();

            string sql = @"
                SELECT t.table_id, t.outlet_id, t.table_number, t.table_name, t.capacity, t.section,
                       t.status, COALESCE(b.total_amount, 0) as current_total, b.bill_no
                FROM tables t
                LEFT JOIN (
                    SELECT table_id, total_amount, bill_no
                    FROM bills
                    WHERE bill_status IN ('open', 'printed', 'partial')
                    AND bill_date = CURDATE()
                ) b ON t.table_id = b.table_id
                WHERE t.outlet_id = @outletId AND t.is_active = TRUE
                ORDER BY t.table_number";

            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@outletId", outletId);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var statusStr = reader.GetString("status");
                var status = statusStr switch
                {
                    "occupied" => TableStatus.Occupied,
                    "reserved" => TableStatus.Reserved,
                    "cleaning" => TableStatus.Unpaid,
                    "maintenance" => TableStatus.Reserved,
                    _ => TableStatus.Available
                };

                // If there's an uncleared bill, mark as Unpaid
                var currentTotal = reader.GetDecimal("current_total");
                if (currentTotal > 0 && status == TableStatus.Available)
                    status = TableStatus.Unpaid;

                tables.Add(new Table
                {
                    TableId = reader.GetInt32("table_id"),
                    OutletId = reader.GetInt32("outlet_id"),
                    TableNumber = reader.GetString("table_number"),
                    TableName = reader.IsDBNull("table_name") ? "" : reader.GetString("table_name"),
                    Capacity = reader.GetInt32("capacity"),
                    Section = reader.IsDBNull("section") ? "" : reader.GetString("section"),
                    Status = status,
                    CurrentTotal = currentTotal,
                    CurrentOrderNumber = reader.IsDBNull("bill_no") ? "" : reader.GetString("bill_no")
                });
            }
            return tables;
        }

        // ===================== ORDERS =====================
        public int SaveOrder(Order order)
        {
            using var conn = GetConnection();
            conn.Open();
            using var tx = conn.BeginTransaction();

            try
            {
                // Insert order
                string orderSql = @"
                    INSERT INTO orders (order_no, branch_id, outlet_id, table_id, customer_id, waiter_id,
                        order_type, guest_count, subtotal, tax_amount, service_charge, discount_amount,
                        total_amount, order_status, special_instructions, order_time, created_by)
                    VALUES (@orderNo, @branchId, @outletId, @tableId, @customerId, @waiterId,
                        @orderType, @guestCount, @subtotal, @taxAmount, @serviceCharge, @discountAmount,
                        @totalAmount, @status, @instructions, @orderTime, @createdBy);
                    SELECT LAST_INSERT_ID();";

                using var cmd = new MySqlCommand(orderSql, conn, tx);
                cmd.Parameters.AddWithValue("@orderNo", order.OrderNumber);
                cmd.Parameters.AddWithValue("@branchId", order.BranchId);
                cmd.Parameters.AddWithValue("@outletId", order.OutletId);
                cmd.Parameters.AddWithValue("@tableId", order.TableId ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@customerId", order.CustomerId ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@waiterId", order.WaiterId ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@orderType", order.OrderType);
                cmd.Parameters.AddWithValue("@guestCount", order.GuestCount);
                cmd.Parameters.AddWithValue("@subtotal", order.SubTotal);
                cmd.Parameters.AddWithValue("@taxAmount", order.TaxAmount);
                cmd.Parameters.AddWithValue("@serviceCharge", order.ServiceCharge);
                cmd.Parameters.AddWithValue("@discountAmount", order.DiscountAmount);
                cmd.Parameters.AddWithValue("@totalAmount", order.TotalAmount);
                cmd.Parameters.AddWithValue("@status", order.Status.ToString().ToLower());
                cmd.Parameters.AddWithValue("@instructions", order.SpecialInstructions);
                cmd.Parameters.AddWithValue("@orderTime", order.OrderTime);
                cmd.Parameters.AddWithValue("@createdBy", 1); // TODO: from session

                var orderId = Convert.ToInt32(cmd.ExecuteScalar());
                order.OrderId = orderId;

                // Insert order items
                foreach (var item in order.Items)
                {
                    string itemSql = @"
                        INSERT INTO order_items (order_id, item_id, quantity, unit_price,
                            discount_amount, tax_amount, total_price, special_instructions, item_status)
                        VALUES (@orderId, @itemId, @qty, @unitPrice, @discount, @tax, @total, @notes, 'pending')";

                    using var itemCmd = new MySqlCommand(itemSql, conn, tx);
                    itemCmd.Parameters.AddWithValue("@orderId", orderId);
                    itemCmd.Parameters.AddWithValue("@itemId", item.ItemId);
                    itemCmd.Parameters.AddWithValue("@qty", item.Quantity);
                    itemCmd.Parameters.AddWithValue("@unitPrice", item.UnitPrice);
                    itemCmd.Parameters.AddWithValue("@discount", item.DiscountAmount);
                    itemCmd.Parameters.AddWithValue("@tax", item.TaxAmount);
                    itemCmd.Parameters.AddWithValue("@total", item.TotalAmount);
                    itemCmd.Parameters.AddWithValue("@notes", item.Notes);
                    itemCmd.ExecuteNonQuery();
                }

                // Update table status
                if (order.TableId.HasValue)
                {
                    using var tblCmd = new MySqlCommand(
                        "UPDATE tables SET status = 'occupied' WHERE table_id = @tid", conn, tx);
                    tblCmd.Parameters.AddWithValue("@tid", order.TableId.Value);
                    tblCmd.ExecuteNonQuery();
                }

                tx.Commit();
                return orderId;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                MessageBox.Show($"Error saving order: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
                throw;
            }
        }

        public void UpdateOrder(Order order)
        {
            using var conn = GetConnection();
            conn.Open();
            using var tx = conn.BeginTransaction();

            try
            {
                // Delete existing items and re-insert
                using var delCmd = new MySqlCommand("DELETE FROM order_items WHERE order_id = @oid", conn, tx);
                delCmd.Parameters.AddWithValue("@oid", order.OrderId);
                delCmd.ExecuteNonQuery();

                // Update order totals
                string updSql = @"
                    UPDATE orders SET
                        subtotal = @subtotal, tax_amount = @tax, service_charge = @svc,
                        discount_amount = @discount, total_amount = @total,
                        order_status = @status, updated_at = NOW()
                    WHERE order_id = @oid";

                using var updCmd = new MySqlCommand(updSql, conn, tx);
                updCmd.Parameters.AddWithValue("@subtotal", order.SubTotal);
                updCmd.Parameters.AddWithValue("@tax", order.TaxAmount);
                updCmd.Parameters.AddWithValue("@svc", order.ServiceCharge);
                updCmd.Parameters.AddWithValue("@discount", order.DiscountAmount);
                updCmd.Parameters.AddWithValue("@total", order.TotalAmount);
                updCmd.Parameters.AddWithValue("@status", order.Status.ToString().ToLower());
                updCmd.Parameters.AddWithValue("@oid", order.OrderId);
                updCmd.ExecuteNonQuery();

                // Re-insert items
                foreach (var item in order.Items)
                {
                    string itemSql = @"
                        INSERT INTO order_items (order_id, item_id, quantity, unit_price,
                            discount_amount, tax_amount, total_price, special_instructions, item_status)
                        VALUES (@orderId, @itemId, @qty, @unitPrice, @discount, @tax, @total, @notes, 'pending')";

                    using var itemCmd = new MySqlCommand(itemSql, conn, tx);
                    itemCmd.Parameters.AddWithValue("@orderId", order.OrderId);
                    itemCmd.Parameters.AddWithValue("@itemId", item.ItemId);
                    itemCmd.Parameters.AddWithValue("@qty", item.Quantity);
                    itemCmd.Parameters.AddWithValue("@unitPrice", item.UnitPrice);
                    itemCmd.Parameters.AddWithValue("@discount", item.DiscountAmount);
                    itemCmd.Parameters.AddWithValue("@tax", item.TaxAmount);
                    itemCmd.Parameters.AddWithValue("@total", item.TotalAmount);
                    itemCmd.Parameters.AddWithValue("@notes", item.Notes);
                    itemCmd.ExecuteNonQuery();
                }

                tx.Commit();
            }
            catch (Exception ex)
            {
                tx.Rollback();
                MessageBox.Show($"Error updating order: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
                throw;
            }
        }

        // ===================== BILLS =====================
        public int SaveBill(Bill bill)
        {
            using var conn = GetConnection();
            conn.Open();

            string sql = @"
                INSERT INTO bills (bill_no, order_id, branch_id, outlet_id, table_id, customer_id,
                    cashier_id, bill_type, subtotal, tax_amount, service_charge, discount_amount,
                    rounding, total_amount, amount_paid, balance_due, tip_amount, bill_status,
                    print_count, bill_date, bill_time, notes, created_at)
                VALUES (@billNo, @orderId, @branchId, @outletId, @tableId, @customerId,
                    @cashierId, @billType, @subtotal, @tax, @svc, @discount, @rounding,
                    @total, @paid, @balance, @tip, @status, @printCount, @billDate, @billTime,
                    @notes, NOW());
                SELECT LAST_INSERT_ID();";

            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@billNo", bill.BillNo);
            cmd.Parameters.AddWithValue("@orderId", bill.OrderId);
            cmd.Parameters.AddWithValue("@branchId", bill.BranchId);
            cmd.Parameters.AddWithValue("@outletId", bill.OutletId);
            cmd.Parameters.AddWithValue("@tableId", bill.TableId ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@customerId", bill.CustomerId ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@cashierId", bill.CashierId ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@billType", bill.BillType);
            cmd.Parameters.AddWithValue("@subtotal", bill.Subtotal);
            cmd.Parameters.AddWithValue("@tax", bill.TaxAmount);
            cmd.Parameters.AddWithValue("@svc", bill.ServiceCharge);
            cmd.Parameters.AddWithValue("@discount", bill.DiscountAmount);
            cmd.Parameters.AddWithValue("@rounding", bill.Rounding);
            cmd.Parameters.AddWithValue("@total", bill.TotalAmount);
            cmd.Parameters.AddWithValue("@paid", bill.AmountPaid);
            cmd.Parameters.AddWithValue("@balance", bill.BalanceDue);
            cmd.Parameters.AddWithValue("@tip", bill.TipAmount);
            cmd.Parameters.AddWithValue("@status", bill.BillStatus.ToString().ToLower());
            cmd.Parameters.AddWithValue("@printCount", bill.PrintCount);
            cmd.Parameters.AddWithValue("@billDate", bill.BillDate);
            cmd.Parameters.AddWithValue("@billTime", bill.BillTime);
            cmd.Parameters.AddWithValue("@notes", bill.Notes);

            return Convert.ToInt32(cmd.ExecuteScalar());
        }

        public List<Bill> GetUnclearedBills(int branchId, int? outletId = null)
        {
            var bills = new List<Bill>();
            using var conn = GetConnection();
            conn.Open();

            string sql = @"
                SELECT b.*, t.table_number
                FROM bills b
                LEFT JOIN tables t ON b.table_id = t.table_id
                WHERE b.bill_status IN ('open', 'printed', 'partial')
                AND b.branch_id = @branchId
                AND (b.is_cleared IS NULL OR b.is_cleared = FALSE)";

            if (outletId.HasValue)
                sql += " AND b.outlet_id = @outletId";

            sql += " ORDER BY b.created_at DESC";

            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@branchId", branchId);
            if (outletId.HasValue)
                cmd.Parameters.AddWithValue("@outletId", outletId.Value);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                bills.Add(MapBill(reader));
            }
            return bills;
        }

        public void MarkBillCleared(int billId)
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand(
                "UPDATE bills SET is_cleared = TRUE, bill_status = 'paid', settled_at = NOW() WHERE bill_id = @id",
                conn);
            cmd.Parameters.AddWithValue("@id", billId);
            cmd.ExecuteNonQuery();
        }

        public void UpdateBillPrintCount(int billId)
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand(
                "UPDATE bills SET print_count = print_count + 1 WHERE bill_id = @id",
                conn);
            cmd.Parameters.AddWithValue("@id", billId);
            cmd.ExecuteNonQuery();
        }

        private Bill MapBill(MySqlDataReader reader)
        {
            return new Bill
            {
                BillId = reader.GetInt32("bill_id"),
                BillNo = reader.GetString("bill_no"),
                OrderId = reader.GetInt32("order_id"),
                BranchId = reader.GetInt32("branch_id"),
                OutletId = reader.GetInt32("outlet_id"),
                TableId = reader.IsDBNull("table_id") ? null : reader.GetInt32("table_id"),
                TableNumber = reader.IsDBNull("table_number") ? "" : reader.GetString("table_number"),
                TotalAmount = reader.GetDecimal("total_amount"),
                BillStatus = Enum.Parse<BillStatus>(reader.GetString("bill_status"), true),
                BillDate = reader.GetDateTime("bill_date"),
                CreatedAt = reader.GetDateTime("created_at")
            };
        }

        // ===================== ORDER NUMBER =====================
        public string GetNextOrderNumber()
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand(
                "SELECT COUNT(*) + 1 as next_id FROM orders WHERE DATE(order_time) = CURDATE()",
                conn);
            var count = Convert.ToInt32(cmd.ExecuteScalar());
            return $"ORD-{DateTime.Now:yyyyMMdd}-{count:D5}";
        }

        public string GetNextBillNumber()
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand(
                "SELECT COUNT(*) + 1 as next_id FROM bills WHERE bill_date = CURDATE()",
                conn);
            var count = Convert.ToInt32(cmd.ExecuteScalar());
            return $"BILL-{DateTime.Now:yyyyMMdd}-{count:D5}";
        }

        // ===================== ACTIVE ORDERS =====================
        public List<Order> GetActiveOrders(int outletId)
        {
            var orders = new List<Order>();
            using var conn = GetConnection();
            conn.Open();

            string sql = @"
                SELECT o.*, t.table_number
                FROM orders o
                LEFT JOIN tables t ON o.table_id = t.table_id
                WHERE o.outlet_id = @outletId
                AND o.order_status NOT IN ('completed', 'cancelled')
                ORDER BY o.order_time DESC";

            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@outletId", outletId);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                orders.Add(new Order
                {
                    OrderId = reader.GetInt32("order_id"),
                    OrderNumber = reader.GetString("order_no"),
                    TableId = reader.IsDBNull("table_id") ? null : reader.GetInt32("table_id"),
                    TableNumber = reader.IsDBNull("table_number") ? "" : reader.GetString("table_number"),
                    TotalAmount = reader.GetDecimal("total_amount"),
                    Status = Enum.Parse<OrderStatus>(reader.GetString("order_status"), true),
                    CustomerName = "Walk-in Customer",
                    CashierName = ""
                });
            }
            return orders;
        }

        public void CancelOrder(int orderId)
        {
            using var conn = GetConnection();
            conn.Open();
            using var tx = conn.BeginTransaction();

            try
            {
                // Update order status
                using var cmd = new MySqlCommand(
                    "UPDATE orders SET order_status = 'cancelled', updated_at = NOW() WHERE order_id = @id",
                    conn, tx);
                cmd.Parameters.AddWithValue("@id", orderId);
                cmd.ExecuteNonQuery();

                // Free up table
                using var tblCmd = new MySqlCommand(
                    "UPDATE tables SET status = 'available' WHERE table_id = (SELECT table_id FROM orders WHERE order_id = @id)",
                    conn, tx);
                tblCmd.Parameters.AddWithValue("@id", orderId);
                tblCmd.ExecuteNonQuery();

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        public void ChangeTable(int orderId, int newTableId, int? oldTableId)
        {
            using var conn = GetConnection();
            conn.Open();
            using var tx = conn.BeginTransaction();

            try
            {
                // Update order table
                using var cmd = new MySqlCommand(
                    "UPDATE orders SET table_id = @newTable WHERE order_id = @oid",
                    conn, tx);
                cmd.Parameters.AddWithValue("@newTable", newTableId);
                cmd.Parameters.AddWithValue("@oid", orderId);
                cmd.ExecuteNonQuery();

                // Free old table
                if (oldTableId.HasValue)
                {
                    using var oldCmd = new MySqlCommand(
                        "UPDATE tables SET status = 'available' WHERE table_id = @tid",
                        conn, tx);
                    oldCmd.Parameters.AddWithValue("@tid", oldTableId.Value);
                    oldCmd.ExecuteNonQuery();
                }

                // Occupy new table
                using var newCmd = new MySqlCommand(
                    "UPDATE tables SET status = 'occupied' WHERE table_id = @tid",
                    conn, tx);
                newCmd.Parameters.AddWithValue("@tid", newTableId);
                newCmd.ExecuteNonQuery();

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }
    }
}
